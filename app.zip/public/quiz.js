let quizData;

async function fetchQuizData() {
  const response = await fetch('/submit', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({}),
  });
  quizData = await response.json();
  renderQuiz();
}

function renderQuiz() {
  const quizContainer = document.getElementById('quiz-container');
  quizContainer.innerHTML = '';

  quizData.forEach((question) => {
    const questionDiv = document.createElement('div');
    questionDiv.innerHTML = `
      <p>${question.question}</p>
      ${question.options.map((option) => `<label><input type="radio" name="${question._id}" value="${option}">${option}</label>`).join('')}
    `;
    quizContainer.appendChild(questionDiv);
  });
}

function submitAnswers() {
  const submittedAnswers = {};

  quizData.forEach((question) => {
    const selectedOption = document.querySelector(`input[name="${question._id}"]:checked`);
    submittedAnswers[question._id] = selectedOption ? selectedOption.value : '';
  });

  fetch('/submit', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams(submittedAnswers),
  })
  .then(response => response.json())
  .then(data => alert(`Your score: ${data.score} / ${data.totalQuestions}`));
}

fetchQuizData();
