const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const { MongoClient } = require('mongodb');

const app = express();
const port = 3000;

const mongoURI = 'mongodb+srv://vanshika1318:01022004-07@cluster0.3cr96gd.mongodb.net/?retryWrites=true&w=majority';
const dbName = '2111981318';
const userCollectionName = 'Users';
const quizCollectionName = 'Questions';

app.use(session({
  secret: process.env.SESSION_SECRET || 'defaultSecret',
  resave: false,
  saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());

passport.use(new LocalStrategy(
  async (username, password, done) => {
    const client = new MongoClient(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true });

    try {
      await client.connect();
      console.log('Connected to MongoDB');

      const database = client.db(dbName);
      const collection = database.collection(userCollectionName);

      const user = await collection.findOne({ username });

      if (user && user.password === password) {
        return done(null, user);
      } else {
        return done(null, false, { message: 'Incorrect username or password' });
      }
    } finally {
      await client.close();
      console.log('Disconnected from MongoDB');
    }
  }
));

passport.serializeUser((user, done) => {
  done(null, user._id);
});

passport.deserializeUser(async (id, done) => {
  const client = new MongoClient(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true });

  try {
    await client.connect();
    console.log('Connected to MongoDB');

    const database = client.db(dbName);
    const collection = database.collection(userCollectionName);

    const user = await collection.findOne({ _id: id });

    done(null, user);
  } finally {
    await client.close();
    console.log('Disconnected from MongoDB');
  }
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Serve the login or signup page
app.get('/auth', (req, res) => {
  res.sendFile(__dirname + '/public/auth.html');
});

// Handle the login or signup form submission
app.post('/auth',
  passport.authenticate('local', {
    successRedirect: '/quiz',
    failureRedirect: '/auth',
  })
);

// Redirect to the auth page if not authenticated
app.get('/quiz', ensureAuthenticated, (req, res) => {
  res.sendFile(__dirname + '/public/quiz.html');
});

// Ensure user is authenticated
function ensureAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.redirect('/auth');
}

// Other routes remain unchanged...

app.listen(3000, () => {
  console.log("Server connected");
});
